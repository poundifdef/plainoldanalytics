repo: poundifdef/plainoldanalytics
branch: master

## Last sync
date: 2026-09-13T03:17:34Z

### Updated in this project
- Read the repo as a capability reference (not a UI recreation) for a new dashboard design.
- Built `Analytics Dashboard.dc.html` covering overview, traffic log, sessions, replay, events, visitor, settings, first-run.

## Screen map
| Screen | Repo files it was built from |
| --- | --- |
| Overview | webapp/dashboard.go, webapp/ua.go, storage/storage.go |
| Traffic log + request detail | storage/storage.go (Traffic, TrafficFilter), README.md (capture.Set) |
| Sessions / Session replay | storage/storage.go (Session, ReplayChunk, Replay) |
| Events | storage/storage.go (Event, EventFilter) |
| Visitor | storage/storage.go (Visitor IDs, TrafficFilter) |
| Settings / first run | README.md (snippet, storage, WithUserKey) |
